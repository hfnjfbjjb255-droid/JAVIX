# JAVIX — جاهز للبناء

هذا الأرشيف يحتوي على مشروع Flutter الكامل، بما فيه مجلد `android/` وملفات `lib/` والأيقونة.

## البناء عبر GitHub Actions

1. ارفع محتويات هذا المجلد إلى مستودع GitHub.
2. يجب أن يكون `pubspec.yaml` في جذر المستودع.
3. افتح تبويب **Actions** وشغّل **Build JAVIX APK**.
4. بعد نجاح البناء، افتح الـrun ثم **Artifacts** ثم `JAVIX-APK`.

ملف GitHub Actions الموجود في:
`.github/workflows/build-apk.yml`

يقوم تلقائياً بـ:
- إعداد Java 17.
- إعداد Flutter 3.47.2.
- تثبيت Android SDK API 35.
- إنشاء ملفات Gradle Wrapper إذا لم تكن موجودة.
- `flutter pub get`.
- `flutter analyze`.
- بناء APK Release لـ Android ARM64.
- رفع ملف APK كـArtifact.

## البناء المحلي

إذا كان Flutter مثبتاً:

```bash
flutter pub get
flutter analyze
flutter build apk --release --target-platform android-arm64
```

الناتج:
`build/app/outputs/flutter-apk/app-release.apk`

## معلومات التطبيق

- اسم التطبيق: JAVIX
- Application ID: `com.javix.app`
- Minimum SDK: 21
- Target/Compile SDK: 35
- إصدار المشروع: 1.0.0+1
