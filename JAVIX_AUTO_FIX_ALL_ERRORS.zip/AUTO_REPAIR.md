# JAVIX automatic repair

The GitHub build tries up to 8 safe repair/rebuild cycles. It can automatically refresh dependencies, repair Flutter Gradle integration, accept Android SDK licenses, clear Gradle/Kotlin caches, apply `dart fix`, format Dart code, and repair common Java/JVM compatibility settings.

It does not blindly rewrite arbitrary application logic. Unknown errors are preserved in logs so a real fix can be made without silently corrupting the app.
