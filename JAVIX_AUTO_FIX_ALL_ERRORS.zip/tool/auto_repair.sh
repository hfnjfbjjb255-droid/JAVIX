#!/usr/bin/env bash
# JAVIX AUTO-FIX BUILD ENGINE
# Repeats diagnosis -> safe repair -> rebuild for common Flutter/Android/Dart errors.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
MAX_ATTEMPTS="${MAX_ATTEMPTS:-8}"
LOG_DIR="${LOG_DIR:-$ROOT/.auto_repair_logs}"
mkdir -p "$LOG_DIR"

need() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: $1 is not installed"; exit 1; }; }
need flutter

write_local_properties() {
  [ -n "${FLUTTER_ROOT:-}" ] && printf 'flutter.sdk=%s\n' "$FLUTTER_ROOT" > android/local.properties || true
}

repair_gradle() {
  write_local_properties
  python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
if p.exists():
    s=p.read_text()
    if 'dev.flutter.flutter-gradle-plugin' not in s and 'plugins {' in s:
        s=s.replace('plugins {', "plugins {\n    id 'dev.flutter.flutter-gradle-plugin'", 1)
    p.write_text(s)
PY
  if [ ! -f android/settings.gradle ] || ! grep -q 'dev.flutter.flutter-plugin-loader' android/settings.gradle; then
    cat > android/settings.gradle <<'SETTINGS'
pluginManagement {
    def flutterSdkPath = {
        def properties = new Properties()
        file('local.properties').withInputStream { properties.load(it) }
        def flutterSdkPath = properties.getProperty('flutter.sdk')
        assert flutterSdkPath != null, 'flutter.sdk not set in local.properties'
        return flutterSdkPath
    }()
    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
plugins {
    id 'dev.flutter.flutter-plugin-loader' version '1.0.0'
    id 'com.android.application' version '8.9.2' apply false
    id 'org.jetbrains.kotlin.android' version '2.1.20' apply false
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories { google(); mavenCentral() }
}
rootProject.name='javix'
include ':app'
SETTINGS
  fi
}

safe_cleanup() {
  flutter clean || true
  rm -rf android/.gradle .dart_tool/build || true
  flutter pub get || true
}

safe_dart_fix() {
  dart fix --apply || true
  dart format lib >/dev/null 2>&1 || true
  flutter pub get || true
}

repair_from_log() {
  local log="$1"
  local changed=1
  # Flutter Gradle integration / wrapper / plugin loader
  if grep -qiE 'Could not find method flutter|flutter\(\)|flutter-gradle-plugin|flutter-plugin-loader|Plugin .* was not found|Gradle.*plugin' "$log"; then
    echo '[AUTO] Flutter/Gradle integration error -> repairing Gradle files'
    repair_gradle
  elif grep -qiE 'SDK location not found|ANDROID_HOME|Android SDK|cmdline-tools|platforms;android' "$log"; then
    echo '[AUTO] Android SDK error -> refreshing SDK configuration'
    write_local_properties
    if [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
      yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
      "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" platform-tools 'platforms;android-35' 'build-tools;35.0.0' || true
    fi
  elif grep -qiE 'license.*not accepted|licenses.*not accepted' "$log"; then
    if [ -n "${ANDROID_HOME:-}" ] && [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
      yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
    fi
  elif grep -qiE 'Could not resolve|Could not find .*artifact|dependency.*failed|Execution failed for task.*[Cc]ompile|A problem occurred configuring project' "$log"; then
    echo '[AUTO] Dependency/Gradle cache error -> clearing project caches'
    safe_cleanup
  elif grep -qiE 'version solving failed|pub get failed|Because .* depends on|pubspec.*conflict' "$log"; then
    echo '[AUTO] Pub dependency conflict detected -> refreshing dependencies'
    rm -f pubspec.lock
    flutter pub get || true
  elif grep -qiE 'Undefined name|isn.t defined|argument_type_not_assignable|invalid_assignment|missing_required_argument|unused_import|dead_code|The getter .* isn.t defined' "$log"; then
    echo '[AUTO] Dart analyzer/compiler error -> applying Dart safe fixes'
    safe_dart_fix
  elif grep -qiE 'Kotlin.*error|e: .*\.kt:|Kotlin daemon' "$log"; then
    echo '[AUTO] Kotlin error -> clearing Gradle/Kotlin caches and retrying'
    rm -rf android/.gradle "$HOME/.gradle/caches" "$HOME/.gradle/kotlin" 2>/dev/null || true
  elif grep -qiE 'Java.*version|Unsupported class file|JVM target|source compatibility' "$log"; then
    echo '[AUTO] Java/JVM compatibility error -> repairing Android compile settings'
    python3 - <<'PY'
from pathlib import Path
p=Path('android/app/build.gradle')
if p.exists():
    s=p.read_text()
    s=s.replace('jvmTarget = "1.8"','jvmTarget = \'17\'').replace('jvmTarget = \'1.8\'','jvmTarget = \'17\'')
    s=s.replace('sourceCompatibility JavaVersion.VERSION_1_8','sourceCompatibility JavaVersion.VERSION_17')
    s=s.replace('targetCompatibility JavaVersion.VERSION_1_8','targetCompatibility JavaVersion.VERSION_17')
    p.write_text(s)
PY
  elif grep -qiE 'resource.*not found|uses-sdk|manifest merger failed|Manifest merger failed' "$log"; then
    echo '[AUTO] Android manifest/resource issue -> running Flutter clean and Dart fixes'
    safe_dart_fix
  elif grep -qiE 'Error:|error:|FAILURE:' "$log"; then
    # Last safe generic pass: analyzer fixes + clean rebuild. Never invent source edits.
    echo '[AUTO] Generic build error -> running safe analyzer fixes and clean rebuild'
    safe_dart_fix
    safe_cleanup
  else
    changed=0
  fi
  return $changed
}

repair_gradle
flutter pub get
safe_dart_fix

for attempt in $(seq 1 "$MAX_ATTEMPTS"); do
  log="$LOG_DIR/attempt-${attempt}.log"
  echo
  echo "========== JAVIX AUTO BUILD $attempt/$MAX_ATTEMPTS =========="
  set +e
  flutter analyze 2>&1 | tee "$LOG_DIR/analyze-${attempt}.log"
  ANALYZE=${PIPESTATUS[0]}
  set -e
  if [ "$ANALYZE" -ne 0 ]; then
    cp "$LOG_DIR/analyze-${attempt}.log" "$log"
    if ! repair_from_log "$log"; then
      echo '[AUTO] Analyzer error has no safe automatic repair rule.'
      exit "$ANALYZE"
    fi
    continue
  fi

  set +e
  flutter build apk --release --target-platform android-arm64 --no-tree-shake-icons 2>&1 | tee "$log"
  STATUS=${PIPESTATUS[0]}
  set -e
  if [ "$STATUS" -eq 0 ]; then
    echo '========== JAVIX BUILD SUCCESS =========='
    exit 0
  fi

  if ! repair_from_log "$log"; then
    echo '[AUTO] Error is not safely auto-repairable by the built-in rules.'
    echo "[AUTO] Full log: $log"
    exit "$STATUS"
  fi
done

echo '[AUTO] Maximum automatic repair attempts reached.'
exit 1
