# بناء JAVIX APK — Android + GitHub Actions

هذا الإصدار يحتوي على مجلد Android جاهز، إعدادات Gradle/AGP/Kotlin، صلاحيات Android، وأيقونة JAVIX.

## البناء على GitHub

1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. تأكد أن الملف `.github/workflows/build-apk.yml` موجود.
3. من تبويب **Actions** شغّل **Build JAVIX APK** ثم **Run workflow**.
4. بعد نجاح البناء افتح الـ run ثم قسم **Artifacts** وحمّل `JAVIX-APK`.

بيئة البناء المستخدمة:
- Flutter 3.47.2
- Dart المرفق مع Flutter
- Java 17
- Gradle 8.11.1
- Android SDK Platform 35
- Android Build Tools 35.0.0
- minSdk 21 / targetSdk 35

## البناء المحلي

```bash
flutter pub get
flutter analyze
cd android
gradle wrapper --gradle-version 8.11.1 --distribution-type bin
chmod +x gradlew
cd ..
flutter build apk --release --target-platform android-arm64 --no-tree-shake-icons
```

الناتج:
`build/app/outputs/flutter-apk/app-release.apk`

## ملاحظات

- التطبيق يستخدم `@drawable/ic_launcher` في الإشعارات لأن المشروع يحتوي على الأيقونة داخل `res/drawable` وليس `res/mipmap`.
- التذكيرات تستخدم `inexactAllowWhileIdle`، لذلك لا نضيف صلاحية المنبهات الدقيقة غير الضرورية.
- OCR الحالي مهيأ للـ Latin؛ النص العربي الكامل يحتاج إضافة/تغيير recognizer مناسب.
- تسجيل دخول المطور تجريبي فقط، وليس نظام مصادقة آمن للإنتاج.
