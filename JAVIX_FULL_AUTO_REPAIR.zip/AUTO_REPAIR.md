# JAVIX automatic build repair

The GitHub Actions build runs `tool/auto_repair.sh` before compiling.
It repairs common Flutter Gradle integration problems, runs `dart fix --apply`
for fixes that Dart can safely determine, formats the Dart source, refreshes
packages, and then analyzes and builds the APK.

This cannot safely invent fixes for arbitrary application logic or dependency
API changes. Such errors are left visible in the Actions log instead of being
silently changed.
