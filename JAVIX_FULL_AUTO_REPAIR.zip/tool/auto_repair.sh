#!/usr/bin/env bash
# JAVIX build self-repair helper.
# It repairs common Flutter/Android build configuration problems and applies
# Dart's safe automatic fixes. It does not pretend to fix arbitrary logic errors.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v flutter >/dev/null 2>&1 || { echo "ERROR: flutter is not installed"; exit 1; }

mkdir -p android

if [ -n "${FLUTTER_ROOT:-}" ]; then
  printf 'flutter.sdk=%s\n' "$FLUTTER_ROOT" > android/local.properties
fi

# Repair the modern Flutter Gradle plugin wiring if an older project is detected.
if ! grep -q "dev.flutter.flutter-gradle-plugin" android/app/build.gradle 2>/dev/null; then
  python3 - <<'PY'
from pathlib import Path
p = Path('android/app/build.gradle')
s = p.read_text()
if "dev.flutter.flutter-gradle-plugin" not in s:
    marker = "plugins {\n"
    if marker not in s:
        raise SystemExit("android/app/build.gradle has no plugins block")
    s = s.replace(marker, marker + "    id 'dev.flutter.flutter-gradle-plugin'\n", 1)
p.write_text(s)
PY
fi

# If settings.gradle is missing Flutter's included build/plugin loader, replace it
# with a minimal compatible Flutter 3.x configuration while preserving app identity.
if ! grep -q "dev.flutter.flutter-plugin-loader" android/settings.gradle 2>/dev/null; then
  cat > android/settings.gradle <<'SETTINGS'
pluginManagement {
    def flutterSdkPath = {
        def properties = new Properties()
        file('local.properties').withInputStream { properties.load(it) }
        def flutterSdkPath = properties.getProperty('flutter.sdk')
        assert flutterSdkPath != null, 'flutter.sdk not set in local.properties'
        return flutterSdkPath
    }()

    includeBuild("$flutterSdkPath/packages/flutter_tools/gradle")

    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

plugins {
    id 'dev.flutter.flutter-plugin-loader' version '1.0.0'
    id 'com.android.application' version '8.9.2' apply false
    id 'org.jetbrains.kotlin.android' version '2.1.20' apply false
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = 'javix'
include ':app'
SETTINGS
fi

# Safe automatic Dart fixes supplied by the Dart analyzer.
flutter pub get
(dart fix --apply || true)
flutter pub get

# Formatting is non-destructive for semantics and helps prevent analyzer noise.
dart format lib >/dev/null || true

echo "JAVIX_AUTO_REPAIR_OK"
